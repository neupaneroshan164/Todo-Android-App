#A Sample TODO Anroid Application Project
**Version 1.0.0.**

A sample Mobile Application project to build TODO anroid application using MVVM pattern, observer Pattern, 
Life Cycle aware components and view Model.

##Software
Anroid Studio v4.0

##Getting Started
In this App user can add the task with Task Title, Description, Date, Priority and the user also can tick the check box weather the 
Task is completed in given date or not. Lets Go through the step by step of the Mobile Application.
Spet 1:
The login system: user should login to add the task and the username is "admin" and the password is "test". In the app there is a validation 
		  where is the user provides the incorrect username and password the system didnot let the user to login moreover it provides 
		  the information that username and password is invalid.
		  Also there is a validation for the blank input value which means if the user mistakely tries to login without providing
		  the login credential the system warns by saying the test area must be filled.
		  There are Two buttons in the Login Page which are 'Sign in' and 'Cancel' where user can sign in and can add the task in signin button 
                  and in the cancel button user are able not to login.

Step 2:
Add Task: After the successfully login the user are able to see the GUI interface of add task page. In this page user can see the floating button
	  with + sign where user can click the button to add the task.  
Step 3:
add task form: After clicking the floating button now user are able to see the form where user can easily add their To Do task.
	       The form consist of Task title, Task Description, Date, Priority (High, Medium, Low) and the check box where the task is completed or not.
	       There are Two buttons 'Save' where user can save the inserted task and the button called 'cancel' where user can cancel the adding process.
	       In this page there is a validation where the user mistakely press the save buton without inserting the task the system gives the information
	       that the filed should not be empty. 
Step 4:
Task List: After Successfully adding the task user are able to see the list of their task. In this Page there is the menu button the the Top left where there
	   are three menus 'Delete Completed' 'Delete All' and 'Logout'. There is the swipping function where user are able to swip the task for deleting the task 
	   particularly by the task Id.
	   Menu: 'Delete Completed'- user can delete all the completed task by pressing this button.
		 'Delete All'- user can delete all the list of the task.
		 'Logout'-user are able to logout the session.
Step 5: In the list Interface user can press the particular task and can update the task where by pressing the task the form page is open with the previous data 
	where user  can change and can tick the check box wether the task is completed or not.  
 	
 

##Author
Roshan Neupane
c7190064
L6 Final Shemester

##License&Copyright
©Roshan Neupane, The British College, Thapathali Kathmandu

In Future


 

